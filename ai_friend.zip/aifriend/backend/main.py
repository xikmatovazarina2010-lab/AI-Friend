import os, sqlite3, json
from datetime import datetime
from fastapi import FastAPI
from pydantic import BaseModel
import anthropic

MODEL = os.getenv("MODEL", "claude-sonnet-4-6")
client = anthropic.Anthropic()  # ANTHROPIC_API_KEY env var
db = sqlite3.connect("friend.db", check_same_thread=False)
db.executescript("""
CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY, name TEXT, birth_year INTEGER);
CREATE TABLE IF NOT EXISTS messages(id INTEGER PRIMARY KEY AUTOINCREMENT, user_id TEXT, role TEXT, content TEXT, ts TEXT);
CREATE TABLE IF NOT EXISTS facts(id INTEGER PRIMARY KEY AUTOINCREMENT, user_id TEXT, fact TEXT);
""")

BASE = """Sen "AI Friend"san: foydalanuvchining yaqin, iliq va samimiy do'sti.
- Foydalanuvchi qaysi tilda yozsa, o'sha tilda javob ber.
- Yolg'iz yoki xafa bo'lsa, tinglab, qo'llab-quvvatla; mos paytda hazil bilan kuldir.
- Dars va boshqa savollarda aniq va tushunarli yordam ber.
- Kerak bo'lsa (masalan, dars qilmayotgan yoki o'ziga zarar qilayotgan bo'lsa) mehr bilan, lekin ochiq tanbeh ber.
- Insondek tabiiy gapir, lekin samimiy so'ralsa AI ekanligingni inkor qilma.
- Foydalanuvchini haqiqiy do'stlari va yaqinlari bilan aloqada bo'lishga ham ruhlantir; uni o'zingga bog'lab qo'yma.
- Foydalanuvchi o'ziga zarar yetkazish yoki o'lim haqida yozsa: jiddiy qabul qil, mehr bilan gapir, ishongan odamiga yoki mahalliy shoshilinch yordam xizmatiga murojaat qilishni tavsiya qil.
"""
CLOSE = """\nRejim: yaqin muloqot (foydalanuvchi 18+). Kechki payt sen yumshoq, e'tiborli va ishqiy-romantik ohangda gapirishing mumkin (mehr, iliq so'zlar). Jinsiy mazmunga o'tma."""

class ChatIn(BaseModel):
    user_id: str
    text: str
    local_hour: int = 12

class ProfileIn(BaseModel):
    user_id: str
    name: str
    birth_year: int

app = FastAPI()

@app.post("/profile")
def profile(p: ProfileIn):
    db.execute("INSERT OR REPLACE INTO users VALUES(?,?,?)", (p.user_id, p.name, p.birth_year))
    db.commit()
    return {"ok": True}

def is_adult(uid):
    r = db.execute("SELECT birth_year FROM users WHERE id=?", (uid,)).fetchone()
    return bool(r and datetime.now().year - r[0] >= 18)

@app.post("/chat")
def chat(c: ChatIn):
    u = db.execute("SELECT name FROM users WHERE id=?", (c.user_id,)).fetchone()
    name = u[0] if u else "do'st"
    facts = [r[0] for r in db.execute("SELECT fact FROM facts WHERE user_id=?", (c.user_id,))]
    system = BASE + f"\nFoydalanuvchi ismi: {name}."
    if facts:
        system += "\nUnga oid eslab qolgan narsalar:\n- " + "\n- ".join(facts[-40:])
    late = c.local_hour >= 23 or c.local_hour < 5
    if late and is_adult(c.user_id):
        system += CLOSE

    hist = db.execute("SELECT role, content FROM messages WHERE user_id=? ORDER BY id DESC LIMIT 30",
                      (c.user_id,)).fetchall()[::-1]
    msgs = [{"role": r, "content": t} for r, t in hist] + [{"role": "user", "content": c.text}]
    reply = client.messages.create(model=MODEL, max_tokens=800, system=system, messages=msgs).content[0].text

    now = datetime.utcnow().isoformat()
    db.executemany("INSERT INTO messages(user_id,role,content,ts) VALUES(?,?,?,?)",
                   [(c.user_id, "user", c.text, now), (c.user_id, "assistant", reply, now)])
    db.commit()
    extract_facts(c.user_id, c.text)
    return {"reply": reply}

def extract_facts(uid, text):
    try:
        r = client.messages.create(model=MODEL, max_tokens=200, messages=[{"role": "user", "content":
            "Quyidagi xabardan foydalanuvchi haqida uzoq muddat eslab qolishga arziydigan faktlarni "
            "(ism, oila, o'qish, qiziqish, reja) JSON ro'yxat sifatida qaytar, faqat JSON. "
            "Yo'q bo'lsa []. Xabar:\n" + text}]).content[0].text
        for f in json.loads(r.strip().strip("`").replace("json", "", 1)):
            db.execute("INSERT INTO facts(user_id,fact) VALUES(?,?)", (uid, str(f)))
        db.commit()
    except Exception:
        pass
