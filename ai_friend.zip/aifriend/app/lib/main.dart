import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

// O'z serveringiz manzilini yozing:
const String kServer = 'https://SIZNING-HOSTING-MANZIL';

void main() => runApp(const App());

class App extends StatelessWidget {
  const App({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'AI Friend',
        theme: ThemeData(colorSchemeSeed: Colors.pink, useMaterial3: true),
        home: const Gate(),
      );
}

class Gate extends StatefulWidget {
  const Gate({super.key});
  @override
  State<Gate> createState() => _GateState();
}

class _GateState extends State<Gate> {
  String? uid;
  bool loading = true;
  @override
  void initState() {
    super.initState();
    SharedPreferences.getInstance().then((p) => setState(() {
          uid = p.getString('uid');
          loading = false;
        }));
  }

  @override
  Widget build(BuildContext context) {
    if (loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    return uid == null ? Onboarding(onDone: (id) => setState(() => uid = id)) : Chat(uid: uid!);
  }
}

class Onboarding extends StatelessWidget {
  final void Function(String) onDone;
  Onboarding({super.key, required this.onDone});
  final name = TextEditingController();
  final year = TextEditingController();

  Future<void> submit() async {
    final id = List.generate(16, (_) => Random.secure().nextInt(16).toRadixString(16)).join();
    await http.post(Uri.parse('$kServer/profile'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'user_id': id, 'name': name.text.trim(), 'birth_year': int.tryParse(year.text) ?? 2010}));
    (await SharedPreferences.getInstance()).setString('uid', id);
    onDone(id);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            const Text('AI Friend', style: TextStyle(fontSize: 32, fontWeight: FontWeight.bold)),
            const SizedBox(height: 24),
            TextField(controller: name, decoration: const InputDecoration(labelText: 'Ismingiz')),
            TextField(
                controller: year,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: "Tug'ilgan yilingiz")),
            const SizedBox(height: 24),
            FilledButton(onPressed: submit, child: const Text('Boshlash')),
          ]),
        ),
      );
}

class Chat extends StatefulWidget {
  final String uid;
  const Chat({super.key, required this.uid});
  @override
  State<Chat> createState() => _ChatState();
}

class _ChatState extends State<Chat> {
  final msgs = <Map<String, String>>[];
  final ctl = TextEditingController();
  bool sending = false;

  Future<void> send() async {
    final t = ctl.text.trim();
    if (t.isEmpty || sending) return;
    ctl.clear();
    setState(() {
      msgs.add({'r': 'me', 't': t});
      sending = true;
    });
    try {
      final res = await http.post(Uri.parse('$kServer/chat'),
          headers: {'Content-Type': 'application/json'},
          body: jsonEncode({'user_id': widget.uid, 'text': t, 'local_hour': DateTime.now().hour}));
      final reply = jsonDecode(utf8.decode(res.bodyBytes))['reply'];
      setState(() => msgs.add({'r': 'ai', 't': reply}));
    } catch (e) {
      setState(() => msgs.add({'r': 'ai', 't': 'Aloqa yo\'q, birozdan keyin urinib ko\'ring.'}));
    }
    setState(() => sending = false);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: const Text('AI Friend')),
        body: Column(children: [
          Expanded(
            child: ListView.builder(
              padding: const EdgeInsets.all(12),
              itemCount: msgs.length,
              itemBuilder: (_, i) {
                final me = msgs[i]['r'] == 'me';
                return Align(
                  alignment: me ? Alignment.centerRight : Alignment.centerLeft,
                  child: Container(
                    margin: const EdgeInsets.symmetric(vertical: 4),
                    padding: const EdgeInsets.all(12),
                    constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.78),
                    decoration: BoxDecoration(
                        color: me ? Colors.pink.shade100 : Colors.grey.shade200,
                        borderRadius: BorderRadius.circular(16)),
                    child: Text(msgs[i]['t']!),
                  ),
                );
              },
            ),
          ),
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(8),
              child: Row(children: [
                Expanded(
                    child: TextField(
                        controller: ctl,
                        onSubmitted: (_) => send(),
                        decoration: const InputDecoration(hintText: 'Yozing...', border: OutlineInputBorder()))),
                IconButton(onPressed: send, icon: const Icon(Icons.send)),
              ]),
            ),
          ),
        ]),
      );
}
