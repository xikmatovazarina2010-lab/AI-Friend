# AI Friend

## Server (backend/)
pip install -r requirements.txt
export ANTHROPIC_API_KEY=...   # kalitni faqat serverda saqlang
uvicorn main:app --host 0.0.0.0 --port 8000
(HTTPS orqali hosting manzilingizga joylang)

## Ilova (app/)
1. Flutter o'rnating: https://docs.flutter.dev/get-started/install
2. app/ ichida: flutter create .   (android papkasini yaratadi, lib/ va pubspec.yaml saqlanadi)
3. lib/main.dart ichidagi kServer ga hosting manzilingizni yozing
4. flutter pub get
5. flutter build apk --release
   APK: build/app/outputs/flutter-apk/app-release.apk

## APK ni kompyutersiz yig'ish (GitHub Actions)
1. github.com da bo'sh repo oching (masalan ai-friend).
2. Shu zip ichidagi hamma narsani (.github papkasi bilan) repoga yuklang.
3. Repoda Actions bo'limiga kiring: "Build APK" ishlaydi (5-10 daqiqa).
4. Tugagach, ish ichidagi Artifacts dan ai-friend-apk ni yuklab oling, ichida app-release.apk.
5. APK ni telefonga o'rnating (Noma'lum manbalarga ruxsat bering).
